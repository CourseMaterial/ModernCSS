describe("JavaScript testing", () => {
  it("works", () => {
    expect(1 + 1).toEqual(2)
  })
})
