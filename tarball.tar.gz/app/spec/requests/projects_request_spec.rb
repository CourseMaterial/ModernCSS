require 'rails_helper'

RSpec.describe "Projects", type: :request do

end
