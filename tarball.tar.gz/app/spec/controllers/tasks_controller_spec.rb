require "rails_helper"

RSpec.describe TasksController, type: :controller do

end
