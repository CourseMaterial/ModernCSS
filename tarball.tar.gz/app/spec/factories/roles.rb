FactoryBot.define do
  factory :role do
    user { nil }
    project { nil }
    role_name { "MyString" }
  end
end
